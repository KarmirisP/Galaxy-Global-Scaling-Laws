SPARC Data Directory
====================
- galaxies.csv: Galaxy metadata (disk scale lengths)
- rotation_curves.csv: Observed rotation curves
- oscillations.csv: Derived oscillation parameters

Source: SPARC database (http://astroweb.cwru.edu/SPARC/)
    ===== SPARC DATASET SUMMARY =====
    Galaxies: 175
    Rotation curve points: 3391
    Median disk scale: 2.3 kpc
    Median oscillation scale: 2.0 kpc
    Median epsilon: 0.091
    